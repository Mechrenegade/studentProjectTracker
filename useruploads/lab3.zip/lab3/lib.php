<?php
class person{
    //properties / attributes of the person class
    private $fname;
    private $lname;
    private $age;
    private $sex;

    function __contruct($f,$l){
        $this -> fname = $f;
        $this -> lname = $l;
        echo "Created a new person"
    }
    //create a method class for outside classes to access properties of perosn class_alias
    function getName(){
        return $this ->fname ." ".$this ->lname;

    }


}

$p = new Person("Jon", "Snow");
&p->setAge(32);
// $p contains an instance of the class Person
//$p -> will fail beacause the attributes is private
// the private is used to enforece 'data emcapsulation rules

echo "Person contains:" .$p->getName();
class Student extends Person{
    public $gpa;
    function __contruct($f, $l, $g){
        parent::__contruct($f, $l);
        $this->gpa = $g;

    }
}
$s =new Student("Hodor", "Hodor",3);
$s->setAge(45);
echo "Student GPA is: $s -> gpa <br>";

?>