<?php
//  PHP code 
$var =2; // $ part of the syntax 
$arr-[1,2,3,4,5];
print count($arr); 
$arr=[];// empty array
print count($arr);

$students= ['John', 'Jim','Jerry','Sue'];// another array using strings
echo count($students);// echo and print does the same thing 

function sizeofArr($arr){// a function passing arr as a parameter
    return count($students);
}
echo sizeofArr($students);
?>
<!--HTML CODE -->
