<!DOCTYPE html>
<head>
  
    <title> My favourite sites </title>
     <h1>My Favourite Sites</h1>
     <h2> Aaron Granger </h2>
      </head>

      <?PHP
      echo('<h1> We wrote this with PHP!</h1>')
      ?>
<body>
    
    <th> Here are 4 sentances.<br> These are not interesting sentances.<br> I am now adding the third sentance. <br>This is the final sentance of the paragraph<br></th>
<a href="http://www.w3schools.com">lol I found this on W3Schools.com! :) pretty neat right</a>

<table class="table">
          <thead> 
          <tr>
            <th>Category</th>
            <th>Site</th>
            <th>Logo</th>
          </tr>
          <thead/>
        
        <tr>
            <td>entertainment</td>
             <td> <a href="https://www.facebook.com">facebook link click me!!!!!<br></td>
             <td> <img src="fb.jpg" alt="HTML5 Icon" style="width:100px;height:100px;">
         </tr>
         <tr>
            <td></td>
            <td><a href="https://www.youtube.com">youtube link click me!!!!!<br></td>
             <td> <img src="youtube.jpg" alt="HTML5 Icon" style="width:100px;height:100px;">
        </tr>
         <tr>
            <td></td>
            <td><a href="https://www.twitter.com">twitter link click me!!!!!<br></td>
             <td> <img src="tw.png" alt="HTML5 Icon" style="width:100px;height:100px;">
            <td></td>
        </tr>
        <tr>
            <td>News</td>
             <td> <a href="https://www.trinidadGuardian.com">trinidad Guardian link click me!!!!!<br></td>
              <td> <img src="gu.jpg" alt="HTML5 Icon" style="width:100px;height:100px;">

         </tr>
           <tr>
            <td></td>
            <td><a href="https://BBC.com">BBC link click me!!!!!<br></td>
             <td> <img src="bbc.png" alt="HTML5 Icon" style="width:100px;height:100px;">
        </tr>
          <tr>
            <td></td>
            <td><a href="https://www.caribbean360.com">caribbean360 link click me!!!!!<br></td>
            <td> <img src="360.jpg" alt="HTML5 Icon" style="width:100px;height:100px;">
        </tr>
          
        <tbody/>
        </table>

        <div class = "row">
            <div class = "col-md-12">
                table.table.table-stripped
                    <thead>
                        <tr>
                            <th>First Name</th><th>Last Name</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                            <td>Kyle</td><td>de frietas</td>
                        </tr>   
                        <tr>
                            <td>Vani</td><td>de frietas</td>
                        </tr>  
                        <tr>
                            <td>Ben</td><td>de frietas</td>
                        </tr>  
                        <?php
                            $students = [];
                            $students[] = array("fname"=>"abraham","lname"=>"lucas");
                            $students[] = array("fname"=>"Micheal","lname"=>"Sam");

                            for($i = 0; $i< count($students); $i +=1){
                                echo "<tr>";
                                echo "<td>".$students[$i]['fname']."</td>";
                                echo "<td>".$students[$i]['fname']."</td>";
                                echo "</tr>";
                            }


                        ?>
                        <tr> 
                            <td><form class="form-horizontal">
                                    <fieldset>

                                    <!-- Form Name -->
                                    <legend>Form Name</legend>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-md-4 control-label" for="textinput">UserID</label>  
                                        <div class="col-md-4">
                                        <input id="textinput" name="textinput" type="text" placeholder="ID" class="form-control input-md">
                                        <span class="help-block">help</span>  
                                    </div>
                                    </div>

                                        <!-- Password input-->
                                        <div class="form-group">
                                            <label class="col-md-4 control-label" for="passwordinput">Password Input</label>
                                            <div class="col-md-4">
                                                <input id="passwordinput" name="passwordinput" type="password" placeholder="Enter password here" class="form-control input-md">
                                                <span class="help-block">help</span>
                                        </div>
                                    </div>

                                    </fieldset>
                                    </form>
                                    </tr>
                                </td>

                    </tbpdy>
                    


    </body>
