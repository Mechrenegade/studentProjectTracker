console.log("hello world");
//Creating a varible using varible
var x= "Natilee";
console.log(typeof(x)); //prints string
var l= x.length;// length is a property of the string object
console.log("length of "+ x +" is: "+l); //+used for string concatenation 

var x2= 'Kyle';
console.log(typeof(x2));//is also a string
var age=20;
var age2=20.2;
console.log(typeof(age));//number
console.log(typeof(age2));//number
var x_upper =x.toUpperCase();
console.log(x_upper);
console.log(x);

var letters= x.split('');
console.log(typeof(letters));// object(an array of type object)
console.log(letters.length);

// printing each individual items in array
var i;
for (i=0; i<letters.length; i+=1){
  console.log ("%s is stored at %s", letters[i], i);
}
//for in loop 
for(i in letters){
  console.log ("%s is stored at %s", letters[i], i);
   printEl (letters[i]);
}

function printEl(el){//El prints the element // El ==ELEMENT
    console.log(el);
}
//forEach methods
// passing printEl function inside as a parameter  // printEl gets passed in the forEach
letters.forEach(printEl);

var l= letters.pop();
console.log(l);
console.log("Array now contains");
letters.forEach(printEl);

 l= letters.shift();
console.log(l);
console.log("Array now contains");
letters.forEach(printEl);

 l= letters.push("e")
console.log(l);
console.log("Array now contains");
letters.forEach(printEl);

var l= letters.unshift("e");
console.log(l);
console.log("Array now contains");
letters.forEach(printEl);

// declaring and initializing
var arr=[];// this is an empty array 
arr=[2,4,6,8,10];//array initialized with values


var obj_lit={};//empty object literal
obj_lit['key']='value';

var students ={};
students["natilee"]={
    "sex" :"female",
    "gpa" : 4
};
students["trisha"]={
    "sex" :"female",
    "gpa" : 4
};

//console.log(students.natilee.gpa);// object notation
console.log(students['natilee']['gpa']);//array notation 

var classes={}; //empty object
classes['INFO3410']={};//Store an empty objectat key INFO3410
classes['INFO3410']['num_students'] =40;// Creates a key 'num_students' within theobject stored at the key "INFO3410"

console.dir(classes);
console.dir(students);
